"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AddProductForm() {
  const router = useRouter();
  const [newProduct, setNewProduct] = useState({ name: "", description: "", price: "", imageUrl: "" });
  const [loading, setLoading] = useState(false);

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    await fetch("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newProduct),
    });
    setNewProduct({ name: "", description: "", price: "", imageUrl: "" });
    setLoading(false);
    router.refresh(); // Refresh server component data
  };

  return (
    <div className="form-card" style={{ margin: "0" }}>
      <h2 style={{ marginBottom: "1.5rem" }}>Добавить товар</h2>
      <form onSubmit={handleAddProduct}>
        <div className="form-group">
          <label className="form-label">Название</label>
          <input required className="form-input" value={newProduct.name} onChange={(e) => setNewProduct({...newProduct, name: e.target.value})} />
        </div>
        <div className="form-group">
          <label className="form-label">Описание</label>
          <input required className="form-input" value={newProduct.description} onChange={(e) => setNewProduct({...newProduct, description: e.target.value})} />
        </div>
        <div className="form-group">
          <label className="form-label">Цена (₽)</label>
          <input required type="number" className="form-input" value={newProduct.price} onChange={(e) => setNewProduct({...newProduct, price: e.target.value})} />
        </div>
        <div className="form-group">
          <label className="form-label">URL картинки</label>
          <input required className="form-input" value={newProduct.imageUrl} onChange={(e) => setNewProduct({...newProduct, imageUrl: e.target.value})} />
        </div>
        <button type="submit" className="btn-full" disabled={loading}>
          {loading ? "Публикация..." : "Опубликовать"}
        </button>
      </form>
    </div>
  );
}
