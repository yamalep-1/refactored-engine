import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import AddProductForm from "./AddProductForm";
import LogoutButton from "../components/LogoutButton";

export default async function Dashboard() {
  const session = await getSession();
  
  if (!session) {
    redirect("/login");
  }

  const role = session.role;
  let products = [];
  let users = [];
  let orders = [];

  if (role === "MANAGER") {
    products = await prisma.product.findMany({ orderBy: { id: 'desc' } });
    users = await prisma.user.findMany();
  } else if (role === "SUPPLIER") {
    products = await prisma.product.findMany({ 
      where: { supplierId: session.id },
      orderBy: { id: 'desc' }
    });
  } else if (role === "USER") {
    orders = await prisma.order.findMany({
      where: { userId: session.id },
      orderBy: { id: 'desc' }
    });
  }

  return (
    <div style={{ paddingTop: "2rem", paddingBottom: "4rem" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2rem" }}>
        <div>
          <h1 className="page-title" style={{ marginBottom: "0.5rem" }}>Кабинет</h1>
          <p className="page-subtitle" style={{ marginBottom: 0 }}>
            Вы вошли как <strong>{session.email}</strong> <span className="badge">{role}</span>
          </p>
        </div>
        <LogoutButton />
      </div>

      {role === "USER" && (
        <div className="form-card" style={{ maxWidth: "100%", margin: "0" }}>
          <h2 style={{ marginBottom: "1rem" }}>Мои заказы</h2>
          {orders.length === 0 ? (
            <p className="page-subtitle">У вас пока нет заказов. Перейдите в каталог, чтобы сделать первую покупку.</p>
          ) : (
            <table style={{ width: "100%", textAlign: "left" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--border-color)" }}>
                  <th style={{ padding: "1rem 0" }}>ID Заказа</th>
                  <th>Сумма</th>
                  <th>Статус</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(o => (
                  <tr key={o.id}>
                    <td style={{ padding: "1rem 0" }}>#{o.id}</td>
                    <td>{o.total.toLocaleString('ru-RU')} ₽</td>
                    <td><span className="badge">{o.status}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {role === "SUPPLIER" && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: "2rem" }}>
          <AddProductForm />
          <div>
            <h2 style={{ marginBottom: "1.5rem" }}>Мои товары ({products.length})</h2>
            {products.length === 0 ? <p>У вас еще нет добавленных товаров.</p> : (
              <div className="product-grid" style={{ paddingTop: "0" }}>
                {products.map(p => (
                  <div key={p.id} className="product-card">
                    <img src={p.imageUrl} alt={p.name} className="product-image" style={{ aspectRatio: '1/1' }} />
                    <div className="product-info">
                      <h3 className="product-title">{p.name}</h3>
                      <p className="product-price">{p.price.toLocaleString('ru-RU')} ₽</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {role === "MANAGER" && (
        <div>
          <h2 style={{ marginBottom: "1.5rem" }}>Все пользователи системы ({users.length})</h2>
          <div className="form-card" style={{ maxWidth: "100%", margin: "0 0 2rem 0" }}>
            <table style={{ width: "100%", textAlign: "left" }}>
              <thead>
                <tr style={{ borderBottom: "1px solid var(--border-color)" }}>
                  <th style={{ padding: "1rem 0" }}>ID</th>
                  <th>Имя</th>
                  <th>Email</th>
                  <th>Роль</th>
                </tr>
              </thead>
              <tbody>
                {users.map(u => (
                  <tr key={u.id}>
                    <td style={{ padding: "1rem 0" }}>{u.id}</td>
                    <td>{u.name || '-'}</td>
                    <td>{u.email}</td>
                    <td><span className="badge">{u.role}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <h2 style={{ marginBottom: "1.5rem" }}>Все товары ({products.length})</h2>
          <div className="form-card" style={{ maxWidth: "100%", margin: "0" }}>
            {products.length === 0 ? <p>Товаров нет</p> : (
              <table style={{ width: "100%", textAlign: "left" }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid var(--border-color)" }}>
                    <th style={{ padding: "1rem 0" }}>ID</th>
                    <th>Название</th>
                    <th>Цена</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map(p => (
                    <tr key={p.id}>
                      <td style={{ padding: "1rem 0" }}>{p.id}</td>
                      <td>{p.name}</td>
                      <td>{p.price.toLocaleString('ru-RU')} ₽</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
