import { prisma } from '@/lib/prisma';
import ProductCard from './components/ProductCard';
import FilterSidebar from './components/FilterSidebar';
import SortDropdown from './components/SortDropdown';
import Link from 'next/link';

export default async function Home({ searchParams }: { searchParams: Promise<{ min?: string; max?: string; sort?: string; brands?: string }> }) {
  const params = await searchParams;
  const minPrice = params?.min ? parseFloat(params.min) : 0;
  const maxPrice = params?.max ? parseFloat(params.max) : undefined;
  const sort = params?.sort || "default";

  let orderBy: any = { id: 'desc' };
  if (sort === "price_asc") orderBy = { price: 'asc' };
  else if (sort === "price_desc") orderBy = { price: 'desc' };
  else if (sort === "new") orderBy = { id: 'desc' };

  const products = await prisma.product.findMany({
    where: {
      price: {
        gte: minPrice,
        ...(maxPrice ? { lte: maxPrice } : {})
      }
    },
    orderBy
  });

  return (
    <div className="catalog-page">
      <div className="catalog-layout">
        
        {/* Левая колонка - Сайдбар */}
        <aside>
          <FilterSidebar />
        </aside>

        {/* Правая колонка - Контент */}
        <div>
          <div className="breadcrumbs">
            <Link href="/">ГЛАВНАЯ</Link> / <Link href="/">ОДЕЖДА</Link> / <Link href="/">ПЛАТЬЯ</Link>
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h1 className="catalog-title">Платья</h1>
            <SortDropdown />
          </div>
          
          {products.length === 0 ? (
            <div style={{ padding: '4rem 0', textAlign: 'center', color: 'var(--text-secondary)' }}>
              Товары по заданным фильтрам не найдены.
            </div>
          ) : (
            <div className="product-grid" style={{ paddingTop: 0 }}>
              {products.map((product, i) => (
                <ProductCard key={product.id} product={product} index={i} />
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
