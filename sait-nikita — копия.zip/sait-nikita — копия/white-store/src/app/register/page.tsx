"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Register() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("USER");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password, role }),
    });

    const data = await res.json();
    if (res.ok) {
      window.location.href = "/dashboard";
    } else {
      setError(data.error);
    }
  };

  return (
    <div className="form-card" style={{ marginTop: "2rem" }}>
      <h1 className="page-title" style={{ fontSize: "2rem", textAlign: "center" }}>Регистрация</h1>
      {error && <p style={{ color: "red", marginBottom: "1rem", textAlign: "center" }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Имя</label>
          <input required className="form-input" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div className="form-group">
          <label className="form-label">Email</label>
          <input required type="email" className="form-input" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div className="form-group">
          <label className="form-label">Пароль</label>
          <input required type="password" className="form-input" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <div className="form-group">
          <label className="form-label">Роль аккаунта</label>
          <select className="form-input" value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="USER">Покупатель</option>
            <option value="SUPPLIER">Поставщик</option>
          </select>
        </div>
        <button type="submit" className="btn-full" style={{ marginBottom: "1rem" }}>Зарегистрироваться</button>
      </form>
      <div style={{ textAlign: "center", color: "var(--text-secondary)" }}>
        Уже есть аккаунт? <Link href="/login" style={{ color: "var(--text-primary)", fontWeight: 600 }}>Войти</Link>
      </div>
    </div>
  );
}
