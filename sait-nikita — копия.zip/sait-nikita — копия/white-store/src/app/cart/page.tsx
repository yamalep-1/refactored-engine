"use client";

import { useCart } from "@/context/CartContext";
import { useState } from "react";
import Link from "next/link";

export default function CartPage() {
  const { items, removeFromCart, totalPrice, clearCart } = useCart();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handleCheckout = async () => {
    setLoading(true);
    setError("");
    const res = await fetch("/api/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ total: totalPrice })
    });
    
    if (res.ok) {
      setSuccess(true);
      clearCart();
    } else {
      const data = await res.json();
      setError(data.error);
    }
    setLoading(false);
  };

  if (success) {
    return (
      <div style={{ paddingTop: "4rem", textAlign: "center" }}>
        <h1 className="page-title">Заказ успешно оформлен!</h1>
        <p className="page-subtitle">Спасибо за покупку. Вы можете просмотреть статус заказа в Личном кабинете.</p>
        <Link href="/dashboard" className="btn-full" style={{ display: "inline-block", maxWidth: "200px", marginTop: "2rem" }}>В кабинет</Link>
      </div>
    );
  }

  return (
    <div style={{ paddingTop: "2rem", paddingBottom: "4rem" }}>
      <h1 className="page-title">Корзина</h1>
      
      {items.length === 0 ? (
        <p className="page-subtitle">Ваша корзина пуста. <Link href="/" style={{ color: "var(--text-primary)", fontWeight: 600 }}>В каталог</Link></p>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: "2rem" }}>
          <div>
            {items.map(item => (
              <div key={item.id} style={{ display: "flex", gap: "1rem", borderBottom: "1px solid var(--border-color)", paddingBottom: "1rem", marginBottom: "1rem" }}>
                <img src={item.imageUrl} alt={item.name} style={{ width: "100px", height: "100px", objectFit: "cover", borderRadius: "8px" }} />
                <div style={{ flex: 1 }}>
                  <h3 style={{ fontSize: "1.1rem", marginBottom: "0.5rem" }}>{item.name}</h3>
                  <p style={{ color: "var(--text-secondary)" }}>Количество: {item.quantity}</p>
                  <p style={{ fontWeight: 600, marginTop: "0.5rem" }}>{(item.price * item.quantity).toLocaleString('ru-RU')} ₽</p>
                </div>
                <button 
                  onClick={() => removeFromCart(item.id)}
                  style={{ background: "transparent", color: "red", border: "none", alignSelf: "flex-start", cursor: "pointer", fontWeight: 600 }}
                >
                  Удалить
                </button>
              </div>
            ))}
          </div>
          
          <div>
            <div className="form-card" style={{ margin: "0", position: "sticky", top: "100px" }}>
              <h2 style={{ marginBottom: "1.5rem" }}>Итого</h2>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "1.5rem", fontSize: "1.2rem", fontWeight: 600 }}>
                <span>Сумма заказа:</span>
                <span>{totalPrice.toLocaleString('ru-RU')} ₽</span>
              </div>
              {error && <p style={{ color: "red", marginBottom: "1rem" }}>{error}</p>}
              <button className="btn-full" onClick={handleCheckout} disabled={loading}>
                {loading ? "Оформление..." : "Оформить заказ"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
