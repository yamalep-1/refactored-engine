import type { Metadata } from 'next';
import './globals.css';
import Link from 'next/link';
import { CartProvider } from '@/context/CartContext';
import CartBadge from './components/CartBadge';

export const metadata: Metadata = {
  title: 'LUMIÈRE | Premium Clothing',
  description: 'Minimalist white clothing store',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru">
      <body>
        <CartProvider>
          <header className="header">
            <div className="container header-content">
              <Link href="/" className="logo">LUMIÈRE</Link>
              <nav className="nav-links">
                <Link href="/" className="nav-link">Каталог</Link>
                <CartBadge />
                <Link href="/dashboard" className="nav-link">Кабинет</Link>
              </nav>
            </div>
          </header>
          <main className="container">
            {children}
          </main>
        </CartProvider>
      </body>
    </html>
  );
}
