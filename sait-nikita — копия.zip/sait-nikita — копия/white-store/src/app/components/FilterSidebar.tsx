"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState, useEffect } from "react";
import Slider from "rc-slider";
import "rc-slider/assets/index.css";

const ALL_BRANDS = ["FILA", "FILA FUSION", "Adidas Originals", "Lululemon", "Polo Ralph Lauren", "DAVE&BELLA", "DIESEL", "Nike", "Puma", "Reebok"];

export default function FilterSidebar() {
  const router = useRouter();
  const searchParams = useSearchParams();
  
  const [minPrice, setMinPrice] = useState(Number(searchParams.get("min")) || 0);
  const [maxPrice, setMaxPrice] = useState(Number(searchParams.get("max")) || 14963);
  const [brands, setBrands] = useState<string[]>(searchParams.get("brands")?.split(",") || []);

  const [showAllBrands, setShowAllBrands] = useState(false);
  const [isGenderOpen, setIsGenderOpen] = useState(false);

  // Sync inputs when search params change
  useEffect(() => {
    setMinPrice(Number(searchParams.get("min")) || 0);
    setMaxPrice(Number(searchParams.get("max")) || 14963);
  }, [searchParams]);

  const applyPrice = (min: number, max: number) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("min", min.toString());
    params.set("max", max.toString());
    router.push(`/?${params.toString()}`);
  };

  const handleSliderChange = (value: number | number[]) => {
    if (Array.isArray(value)) {
      setMinPrice(value[0]);
      setMaxPrice(value[1]);
    }
  };

  const handleSliderAfterChange = (value: number | number[]) => {
    if (Array.isArray(value)) {
      applyPrice(value[0], value[1]);
    }
  };

  const handlePriceBlur = () => {
    applyPrice(minPrice, maxPrice);
  };

  const toggleBrand = (brand: string) => {
    setBrands(prev => {
      const newBrands = prev.includes(brand) ? prev.filter(b => b !== brand) : [...prev, brand];
      const params = new URLSearchParams(searchParams.toString());
      if (newBrands.length > 0) params.set("brands", newBrands.join(","));
      else params.delete("brands");
      router.push(`/?${params.toString()}`);
      return newBrands;
    });
  };

  const visibleBrands = showAllBrands ? ALL_BRANDS : ALL_BRANDS.slice(0, 5);

  return (
    <div style={{ paddingRight: "1rem" }}>
      {/* Brands */}
      <div className="filter-section">
        <div className="filter-header">
          <span>Бренды</span>
          <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 6.5L6 1.5L11 6.5" stroke="black" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        <div>
          {visibleBrands.map(brand => (
            <label key={brand} className="checkbox-label">
              <input 
                type="checkbox" 
                checked={brands.includes(brand)}
                onChange={() => toggleBrand(brand)}
              />
              {brand}
            </label>
          ))}
          {!showAllBrands && (
            <div className="filter-show-more" onClick={() => setShowAllBrands(true)}>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 1V11M1 6H11" stroke="#6b7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
              Показать больше
            </div>
          )}
          {showAllBrands && (
            <div className="filter-show-more" onClick={() => setShowAllBrands(false)}>
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style={{transform: "rotate(45deg)"}}><path d="M6 1V11M1 6H11" stroke="#6b7280" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
              Скрыть
            </div>
          )}
        </div>
      </div>

      {/* Gender and Age */}
      <div className="filter-section">
        <div className="filter-header" onClick={() => setIsGenderOpen(!isGenderOpen)}>
          <span>Пол и возраст</span>
          <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg" style={{ transform: isGenderOpen ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>
            <path d="M1 1.5L6 6.5L11 1.5" stroke="black" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        {isGenderOpen && (
          <div style={{ marginTop: '1rem' }}>
            <label className="checkbox-label"><input type="checkbox" /> Мужской</label>
            <label className="checkbox-label"><input type="checkbox" /> Женский</label>
            <label className="checkbox-label"><input type="checkbox" /> Детский</label>
          </div>
        )}
      </div>

      {/* Price */}
      <div className="filter-section" style={{ borderBottom: "none" }}>
        <div className="filter-header">
          <span>Цена</span>
          <svg width="12" height="8" viewBox="0 0 12 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1 6.5L6 1.5L11 6.5" stroke="black" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
        </div>
        
        <div style={{ margin: "2rem 0 1.5rem 0", padding: "0 8px" }}>
          <Slider 
            range 
            min={0} 
            max={30000} 
            value={[minPrice, maxPrice]} 
            onChange={handleSliderChange}
            onAfterChange={handleSliderAfterChange}
            trackStyle={[{ backgroundColor: '#000' }]}
            handleStyle={[
              { borderColor: '#000', backgroundColor: '#fff', opacity: 1, boxShadow: 'none' },
              { borderColor: '#000', backgroundColor: '#fff', opacity: 1, boxShadow: 'none' }
            ]}
          />
        </div>

        <div className="price-inputs">
          <div className="price-input-wrapper">
            <input 
              type="number" 
              value={minPrice} 
              onChange={e => setMinPrice(Number(e.target.value))} 
              onBlur={handlePriceBlur}
            />
          </div>
          <span>—</span>
          <div className="price-input-wrapper">
            <input 
              type="number" 
              value={maxPrice} 
              onChange={e => setMaxPrice(Number(e.target.value))} 
              onBlur={handlePriceBlur}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
