"use client";

import Link from "next/link";
import { useCart } from "@/context/CartContext";

export default function CartBadge() {
  const { totalItems } = useCart();

  return (
    <Link href="/cart" className="nav-link" style={{ position: "relative" }}>
      Корзина
      {totalItems > 0 && (
        <span style={{
          position: "absolute",
          top: "-8px",
          right: "-12px",
          background: "var(--accent-color)",
          color: "white",
          borderRadius: "50%",
          padding: "2px 6px",
          fontSize: "0.7rem",
          fontWeight: "bold"
        }}>
          {totalItems}
        </span>
      )}
    </Link>
  );
}
