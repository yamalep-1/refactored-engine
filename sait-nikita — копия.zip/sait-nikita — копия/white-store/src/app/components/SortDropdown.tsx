"use client";

import { useRouter, useSearchParams } from "next/navigation";

export default function SortDropdown() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const handleSort = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const params = new URLSearchParams(searchParams.toString());
    params.set("sort", e.target.value);
    router.push(`/?${params.toString()}`);
  };

  return (
    <div className="sort-container">
      <span className="sort-label">Сортировать по:</span>
      <select 
        className="sort-select" 
        value={searchParams.get("sort") || "default"}
        onChange={handleSort}
      >
        <option value="default">По умолчанию</option>
        <option value="price_asc">Сначала дешевле</option>
        <option value="price_desc">Сначала дороже</option>
        <option value="new">Новинки</option>
      </select>
    </div>
  );
}
