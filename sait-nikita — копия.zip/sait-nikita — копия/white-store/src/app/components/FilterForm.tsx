"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

export default function FilterForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  
  const [q, setQ] = useState(searchParams.get("q") || "");
  const [maxPrice, setMaxPrice] = useState(searchParams.get("maxPrice") || "");

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (maxPrice) params.set("maxPrice", maxPrice);
    
    router.push(`/?${params.toString()}`);
  };

  const handleReset = () => {
    setQ("");
    setMaxPrice("");
    router.push("/");
  };

  return (
    <form onSubmit={handleApply} style={{ display: "flex", gap: "1rem", marginBottom: "2rem", alignItems: "flex-end", flexWrap: "wrap" }}>
      <div style={{ flex: 1, minWidth: "200px" }}>
        <label className="form-label">Поиск</label>
        <input 
          className="form-input" 
          placeholder="Название товара..." 
          value={q} 
          onChange={e => setQ(e.target.value)} 
        />
      </div>
      <div style={{ flex: 1, minWidth: "200px" }}>
        <label className="form-label">Макс. цена (₽)</label>
        <input 
          type="number" 
          className="form-input" 
          placeholder="Любая" 
          value={maxPrice} 
          onChange={e => setMaxPrice(e.target.value)} 
        />
      </div>
      <div style={{ display: "flex", gap: "1rem" }}>
        <button type="submit" style={{ padding: "0.75rem 1.5rem" }}>Применить</button>
        <button type="button" onClick={handleReset} style={{ background: "#f3f4f6", color: "var(--text-primary)" }}>Сбросить</button>
      </div>
    </form>
  );
}
