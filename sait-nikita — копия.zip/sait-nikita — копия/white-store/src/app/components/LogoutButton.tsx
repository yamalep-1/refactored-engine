"use client";

export default function LogoutButton() {
  const handleLogout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/login";
  };

  return (
    <button onClick={handleLogout} style={{ background: "#f3f4f6", color: "var(--text-primary)" }}>
      Выйти
    </button>
  );
}
