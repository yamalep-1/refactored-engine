"use client";

import { useCart } from "@/context/CartContext";

export default function ProductCard({ product, index }: { product: any, index: number }) {
  const { addToCart } = useCart();

  return (
    <div 
      className="product-card animate-fade-in-up"
      style={{ animationDelay: `${index * 0.1}s`, opacity: 0 }}
    >
      <img 
        src={product.imageUrl} 
        alt={product.name} 
        className="product-image"
      />
      <div className="product-info">
        <h3 className="product-title">{product.name}</h3>
        <p className="product-price">{product.price.toLocaleString('ru-RU')} ₽</p>
        <button className="btn-full" onClick={() => addToCart(product)}>
          В корзину
        </button>
      </div>
    </div>
  );
}
