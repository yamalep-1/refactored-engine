import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const session = await getSession();
    if (!session) {
      return NextResponse.json({ error: 'Нужно войти в аккаунт для заказа' }, { status: 401 });
    }

    const { total } = await request.json();
    
    const order = await prisma.order.create({
      data: {
        userId: session.id,
        total: parseFloat(total),
        status: 'ОПЛАЧЕН', // Fake payment success
      }
    });

    return NextResponse.json(order);
  } catch (error) {
    return NextResponse.json({ error: 'Ошибка создания заказа' }, { status: 500 });
  }
}
