"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();
    if (res.ok) {
      window.location.href = "/dashboard";
    } else {
      setError(data.error);
    }
  };

  return (
    <div className="form-card">
      <h1 className="page-title" style={{ fontSize: "2rem", textAlign: "center" }}>Вход</h1>
      {error && <p style={{ color: "red", marginBottom: "1rem", textAlign: "center" }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label className="form-label">Email</label>
          <input required type="email" className="form-input" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div className="form-group">
          <label className="form-label">Пароль</label>
          <input required type="password" className="form-input" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <button type="submit" className="btn-full" style={{ marginBottom: "1rem" }}>Войти</button>
      </form>
      <div style={{ textAlign: "center", color: "var(--text-secondary)" }}>
        Нет аккаунта? <Link href="/register" style={{ color: "var(--text-primary)", fontWeight: 600 }}>Создать</Link>
      </div>
    </div>
  );
}
